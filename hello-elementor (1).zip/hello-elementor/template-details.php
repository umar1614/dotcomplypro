<?php
/*
Template Name: Details Template
*/

get_header();
?>

<div id="primary" class="content-area driver-details">
    <main id="main" class="site-main">
        <div class="container">
            <?php
            // Check if the user_id query parameter is set
            if (isset($_GET['id'])) {
                $user_id = intval($_GET['id']); // Get the user ID as an integer value

                global $wpdb;
                $driver_table = 'driver';
                $boc_table = 'boc';
                $drug_table = 'drug';
                $eca_table = 'eca';
                $ucr_table = 'ucr';
                $vehicle_table = 'vehicle';
                $users_table = 'users';

                // Retrieve the driver details
                $driver = $wpdb->get_row("SELECT * FROM $driver_table WHERE user_id = $user_id");
                // Retrieve the license details from users table
                $users = $wpdb->get_row("SELECT * FROM $users_table WHERE id = $user_id");
                
                echo '</br></br>';
                echo '<h2>Driver Details</h2>';

                if ($driver) {

                    echo '<table class="details-table">';
                    echo '<tr><th>User ID</th><th>First Name</th><th>Last Name</th><th>Drivers</th><th>Date Hired</th><th>Address</th><th>DOB</th><th>SSN</th><th>Phone</th><th>License No.</th></tr>';
                    echo '<tr>';
                    echo '<td>' . $driver->user_id . '</td>';
                    echo '<td>' . $driver->first_name . '</td>';
                    echo '<td>' . $driver->last_name . '</td>';
                    echo '<td>' . $driver->drivers . '</td>';
                    echo '<td>' . $driver->date_hired . '</td>';
                    echo '<td>' . $driver->address . '</td>';
                    echo '<td>' . $driver->date_of_birth . '</td>';
                    echo '<td>' . $driver->ssn . '</td>';
                    echo '<td>' . $driver->phone . '</td>';
                    echo '<td>' . $driver->license_number . '</td>';
                    echo '</tr>';

                    echo '<tr><th>License State</th><th>License Expiry</th><th>Driver License</th><th>Annual Review Record</th><th>Next Due Annual Review Date</th><th>Random Drug</th><th>Date Pre Employement</th><th>Date Last Random Drug</th><th>Date Drug Consortium</th></tr>';
                    echo '<tr>';
                    echo '<td>' . $driver->license_state . '</td>';
                    echo '<td>' . $driver->license_expiry_date . '</td>';
                    echo '<td>';

                    // Check if driver license file exists
                    $driver_license_path = $driver->location . $driver->driver_lic;
                    $driver_license_file = ABSPATH . 'MobileScripts/' . $driver_license_path;

                    if (file_exists($driver_license_file)) {
                        echo '<a href="' . site_url('/') . 'MobileScripts/' . $driver_license_path . '" download>Download</a>';
                    } else {
                        echo 'N/A';
                    }

                    echo '</td>';
                    echo '<td>';

                    // Check if annual review record file exists
                    $annual_review_path = $driver->location . $driver->annual_review_record;
                    $annual_review_file = ABSPATH . 'MobileScripts/' . $annual_review_path;

                    if (file_exists($annual_review_file)) {
                        echo '<a href="' . site_url('/') . 'MobileScripts/' . $annual_review_path . '" download>Download</a>';
                    } else {
                        echo 'N/A';
                    }

                    echo '</td>';
                    echo '<td>' . $driver->next_due_date_annual_review . '</td>';
                    echo '<td>' . $driver->random_drug . '</td>';
                    echo '<td>' . $driver->date_pre_employment . '</td>';
                    echo '<td>' . $driver->date_last_random_drug . '</td>';
                    echo '<td>' . $driver->date_drug_consortium . '</td>';


                    echo '</tr>';
                    echo '<tr><th>Drug Screen</th><th>Medical Exam</th><th>Expiry Medical Exam</th><th>Employment Application</th><th>Personal Matters</th><th>Misc</th><th>Date Terminated</th><th>License Front</th><th>License Back</th></tr>';
                    echo '<tr>';

                    echo '<td>';

                    // Check if drug screen file exists
                    $drug_screen_path = $driver->location . $driver->drug_screen;
                    $drug_screen_file = ABSPATH . 'MobileScripts/' . $drug_screen_path;

                    if (file_exists($drug_screen_file)) {
                        echo '<a href="' . site_url('/') . 'MobileScripts/' . $drug_screen_path . '" download>Download</a>';
                    } else {
                        echo 'N/A';
                    }

                    echo '</td>';
                    echo '<td>';
                    // Check if medical exam file exists
                    $medical_exam_path = $driver->location . $driver->medical_exam;
                    $medical_exam_file = ABSPATH . 'MobileScripts/' . $medical_exam_path;

                    if (file_exists($medical_exam_file)) {
                        echo '<a href="' . site_url('/') . 'MobileScripts/' . $medical_exam_path . '" download>Download</a>';
                    } else {
                        echo 'N/A';
                    }

                    echo '</td>';
                    echo '<td>' . $driver->expiry_date_medical_exam . '</td>';
                    echo '<td>';

                    // Check if employment application file exists
                    $employment_application_path = $driver->location . $driver->employment_application;
                    $employment_application_file = ABSPATH . 'MobileScripts/' . $employment_application_path;

                    if (file_exists($employment_application_file)) {
                        echo '<a href="' . site_url('/') . 'MobileScripts/' . $employment_application_path . '" download>Download</a>';
                    } else {
                        echo 'N/A';
                    }

                    echo '</td>';
                    echo '<td>';

                    // Check if personal matters file exists
                    $personal_matters_path = $driver->location . $driver->personnel_matters;
                    $personal_matters_file = ABSPATH . 'MobileScripts/' . $personal_matters_path;

                    if (file_exists($personal_matters_file)) {
                        echo '<a href="' . site_url('/') . 'MobileScripts/' . $personal_matters_path . '" download>Download</a>';
                    } else {
                        echo 'N/A';
                    }

                    echo '</td>';
                    echo '<td>' . $driver->miscellaneous . '</td>';
                    echo '<td>' . $driver->date_terminated . '</td>';
                     
                   // License Front
                   
                    echo '<td>';
                    if ($users->license_front_img) {
                        $license_front_url = site_url('/') . 'MobileScripts/' . $driver->location . $users->license_front_img;
                        echo '<a href="' . $license_front_url . '" target="_blank">Show</a>';
                    } else {
                        echo 'N/A';
                    }
                    echo '</td>';
                    
                    // License Back
                    echo '<td>';
                    if ($users->license_back_img) {
                        $license_back_url = site_url('/') . 'MobileScripts/' . $driver->location . $users->license_back_img;
                        echo '<a href="' . $license_back_url . '" target="_blank">Show</a>';
                    } else {
                        echo 'N/A';
                    }
                    echo '</td>';
                    echo '</tr>';
                    echo '</table>';
                } else {
                    echo '<p>No Driver data available.</p>';
                }
                // Retrieve the BOC form details
                $boc = $wpdb->get_row("SELECT * FROM $boc_table WHERE user_id = $user_id");

                echo '</br></br>';
                echo '<h2>BOC Form</h2>';
                if ($boc) {
                    echo '<table class="details-table">';
                    echo '<tr><th>User ID</th><th>DOT Number</th><th>Legal Name</th><th>DBA</th><th>State</th></tr>';
                    echo '<tr>';
                    echo '<td>' . $boc->user_id . '</td>';
                    echo '<td>' . $boc->dot_number . '</td>';
                    echo '<td>' . $boc->legal_name . '</td>';
                    echo '<td>' . $boc->dba . '</td>';
                    echo '<td>' . $boc->state . '</td>';
                    echo '</tr>';
                    echo '</table>';
                } else {
                    echo '<p>No BOC form data available.</p>';
                }


                echo '</br></br>';
                echo '<h2>DRUGS</h2>';
                $drug = $wpdb->get_row("SELECT * FROM $drug_table WHERE user_id = $user_id");

                if ($drug) {
                    echo '<table class="details-table">';
                    echo '<tr><th>User ID</th><th>Letter of Participation</th><th>Company Policy</th><th>Program Stats</th><th>Pre Employment</th><th>Random Drug</th><th>Random Alcohol</th><th>Drug Program enrollment with pre-employment drug screen</th><th>Drug Program enrollment without pre-employment drug screen</th></tr>';
                    echo '<tr>';
                    echo '<td>' . $drug->user_id . '</td>';
                    echo '<td>';

                    // Check if Letter of Participation file exists
                    $letter_of_participation_path = $drug->location . $drug->latter_of_participation;
                    $letter_of_participation_file = ABSPATH . 'MobileScripts/' . $letter_of_participation_path;

                    if (file_exists($letter_of_participation_file)) {
                        echo '<a href="' . site_url('/') . 'MobileScripts/' . $letter_of_participation_path . '" download>Download</a>';
                    } else {
                        echo 'N/A';
                    }

                    echo '</td>';

                    echo '<td>';

                    // Check if Company Policy file exists
                    $company_policy_path = $drug->location . $drug->company_policy;
                    $company_policy_file = ABSPATH . 'MobileScripts/' . $company_policy_path;

                    if (file_exists($company_policy_file)) {
                        echo '<a href="' . site_url('/') . 'MobileScripts/' . $company_policy_path . '" download>Download</a>';
                    } else {
                        echo 'N/A';
                    }

                    echo '</td>';
                    echo '<td>';

                    // Check if Program Stats file exists
                    $program_stats_path = $drug->location . $drug->program_stats;
                    $program_stats_file = ABSPATH . 'MobileScripts/' . $program_stats_path;

                    if (file_exists($program_stats_file)) {
                        echo '<a href="' . site_url('/') . 'MobileScripts/' . $program_stats_path . '" download>Download</a>';
                    } else {
                        echo 'N/A';
                    }

                    echo '</td>';
                    echo '<td>';

                    // Check if Pre Employment file exists
                    $pre_employment_path = $drug->location . $drug->pre_employment;
                    $pre_employment_file = ABSPATH . 'MobileScripts/' . $pre_employment_path;

                    if (file_exists($pre_employment_file)) {
                        echo '<a href="' . site_url('/') . 'MobileScripts/' . $pre_employment_path . '" download>Download</a>';
                    } else {
                        echo 'N/A';
                    }

                    echo '</td>';
                    echo '<td>';

                    // Check if Random Drug file exists
                    $random_drug_path = $drug->location . $drug->random_drug;
                    $random_drug_file = ABSPATH . 'MobileScripts/' . $random_drug_path;

                    if (file_exists($random_drug_file)) {
                        echo '<a href="' . site_url('/') . 'MobileScripts/' . $random_drug_path . '" download>Download</a>';
                    } else {
                        echo 'N/A';
                    }

                    echo '</td>';
                    echo '<td>';

                    // Check if Random Alcohol file exists
                    $random_alcohol_path = $drug->location . $drug->random_alcohol;
                    $random_alcohol_file = ABSPATH . 'MobileScripts/' . $random_alcohol_path;

                    if (file_exists($random_alcohol_file)) {
                        echo '<a href="' . site_url('/') . 'MobileScripts/' . $random_alcohol_path . '" download>Download</a>';
                    } else {
                        echo 'N/A';
                    }

                    echo '</td>';
					echo '<td>' . $drug->test . '</td>';
					echo '<td>' . $drug->screen . '</td>';
                    echo '</tr>';
                    echo '</table>';

                } else {
                    echo '<p>No DRUGS data available.</p>';
                }

                echo '</br></br>';
                echo '<h2>ECA</h2>';
                $eca = $wpdb->get_row("SELECT * FROM $eca_table WHERE user_id = $user_id");

                if ($eca) {
                    echo '<table class="details-table">';
                    echo '<tr><th>User ID</th><th>DOT Number</th><th>Docket Type</th><th>Docket Number</th><th>EIN Number</th></tr>';
                    echo '<tr>';
                    echo '<td>' . $eca->user_id . '</td>';
                    echo '<td>' . $eca->dot_number . '</td>';
                    echo '<td>' . $eca->docket_type . '</td>';
                    echo '<td>' . $eca->docket_number . '</td>';
                    echo '<td>' . $eca->ein_number . '</td>';
                    echo '</tr>';
                    echo '</table>';
                } else {
                    echo '<p>No ECA data available.</p>';
                }


                echo '</br></br>';
                echo '<h2>UCR</h2>';
                $ucr = $wpdb->get_row("SELECT * FROM $ucr_table WHERE user_id = $user_id");

                if ($ucr) {
                    echo '<table class="details-table">';
                    echo '<tr><th>User ID</th><th>DOT Number</th><th>Docket Type</th><th>Docket Number</th><th>EIN Number</th><th>Vehicles</th></tr>';
                    echo '<tr>';
                    echo '<td>' . $ucr->user_id . '</td>';
                    echo '<td>' . $ucr->dot_number . '</td>';
                    echo '<td>' . $ucr->docket_type . '</td>';
                    echo '<td>' . $ucr->docket_number . '</td>';
                    echo '<td>' . $ucr->ein_number . '</td>';
					echo '<td>' . $ucr->vehicles . '</td>';
                    echo '</tr>';
                    echo '</table>';


                } else {
                    echo '<p>No UCR data available.</p>';
                }

                echo '</br></br>';
                echo '<h2>Vehicles</h2>';
                $vehicles = $wpdb->get_results("SELECT * FROM $vehicle_table WHERE user_id = $user_id");

                if ($vehicles) {
                    echo '<table class="details-table">';

                    foreach ($vehicles as $vehicle) {
                        echo '<tr><th>User ID</th><th>Unit Number</th><th>Year</th><th>Model</th><th>License</th><th>VIN</th><th>GVWR</th><th>Last Reading date</th><th>OdoMeter Reading</th></tr>';
                        echo '<tr>';
                        echo '<td>' . $vehicle->user_id . '</td>';
                        echo '<td>' . $vehicle->unit_number . '</td>';
                        echo '<td>' . $vehicle->year . '</td>';
                        echo '<td>' . $vehicle->model . '</td>';
                        echo '<td>' . $vehicle->license . '</td>';
                        echo '<td>' . $vehicle->vin . '</td>';
                        echo '<td>' . $vehicle->gvwr . '</td>';
                        echo '<td>' . $vehicle->date_last_reading . '</td>';
                        echo '<td>' . $vehicle->odometer_reading . '</td>';
                        echo '</tr>';

                        echo '<tr><th>Inspection Due Date</th><th>Annual Inspection</th><th>Maintenance Record</th><th>Misc Info</th><th>Misc Files</th></tr>';
                        echo '<tr>';
                        echo '<td>' . $vehicle->date_inspection_due . '</td>';
                        echo '<td>';
                        // Check if Annual Inspection file exists
                        $annual_inspection_path = $vehicle->location . $vehicle->annual_inspection;
                        $annual_inspection_file = ABSPATH . 'MobileScripts/' . $annual_inspection_path;

                        if (file_exists($annual_inspection_file)) {
                            echo '<a href="' . site_url('/') . 'MobileScripts/' . $annual_inspection_path . '" download>Download</a>';
                        } else {
                            echo 'N/A';
                        }
                        echo '</td>';
                        echo '<td>';
                        // Check if Maintenance Record file exists
                        $maintenance_record_path = $vehicle->location . $vehicle->maintenance_record;
                        $maintenance_record_file = ABSPATH . 'MobileScripts/' . $maintenance_record_path;

                        if (file_exists($maintenance_record_file)) {
                            echo '<a href="' . site_url('/') . 'MobileScripts/' . $maintenance_record_path . '" download>Download</a>';
                        } else {
                            echo 'N/A';
                        }
                        echo '</td>';
                        echo '<td>' . $vehicle->miscellaneous_info . '</td>';
                        echo '<td>';
                        // Check if Misc Files file exists
                        $miscellaneous_files_path = $vehicle->location . $vehicle->miscellaneous_files;
                        $miscellaneous_files_file = ABSPATH . 'MobileScripts/' . $miscellaneous_files_path;

                        if (file_exists($miscellaneous_files_file)) {
                            echo '<a href="' . site_url('/') . 'MobileScripts/' . $miscellaneous_files_path . '" download>Download</a>';
                        } else {
                            echo 'N/A';
                        }
                        echo '</td>';
                        echo '</tr>';
                        echo '<tr><td style="border: none !important; background: white !important;" colspan="10"></td></tr>';
                    }

                    echo '</table>';
                } else {
                    echo '<p>No Vehicle data available.</p>';
                }


            } else {
                echo '<p>Invalid user ID.</p>';
            }
            ?>
        </div>
    </main>
</div>


<script>
function showImage(imagePath) {
    var imageUrl = "' . site_url('/') . 'MobileScripts/" + imagePath;
    console.log(imageUrl);
}
</script>


<?php get_footer(); ?>
