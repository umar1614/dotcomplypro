<?php
/*
Template Name: Update Rates
*/

get_header();

wp_enqueue_style('add-boc3-style', get_template_directory_uri() . '/add-boc3-style.css');
   
global $wpdb;
$rates_table = 'rates';

if (isset($_POST['update_rate'])) {
    $product_name = $_POST['product_name'];
    $new_rate = $_POST['new_rate'];
    
    // Update the rate in the database
    $updated = $wpdb->update(
        $rates_table,
        array('rate' => $new_rate),
        array('product_name' => $product_name)
    );


    // Display success message or error
    if ($updated !== false) {
    ?>

    <script>
        alert("Rate Updated Successfully!.");
    </script>
    
    <?php

    } else {
        echo '<p>Error updating rate.</p>';
    }
}

?>

<style>
    .container {
        display: flex;
    }

    .left-half,
    .right-half {
        width: 50%;
        padding: 20px;
    }

    .right-half {
        background-color: #f0f0f0;
    }

    .form-group {
        margin-bottom: 15px;
    }
</style>
<br><br>
<div id="primary" class="content-area search-driver">
    <main id="main" class="site-main">
        <div class="container">
            <div class="left-half">
                <table id="driversTable" class="display">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Rate</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        global $wpdb;
                        $rates_table = 'rates'; // Include the database prefix
                        $rates = $wpdb->get_results("SELECT product_name, rate  FROM $rates_table");
                        foreach ($rates as $rate) {
                            echo '<tr>';
                            echo '<td>' . $rate->product_name . '</td>';
                            echo '<td>' . $rate->rate . '</td>';
                            echo '</tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            <div class="right-half">
                <h2>Update Rates</h2>
                <form method="post" action="">
                    <div class="form-group">
                        <label for="product_name">Product Name:</label>
                        <select name="product_name" id="product_name">
                            <?php
                            // Fetch distinct product names from the 'rates' table
                            $product_names = $wpdb->get_col("SELECT product_name FROM $rates_table");
                            foreach ($product_names as $name) {
                                echo '<option value="' . $name . '">' . $name . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="new_rate">New Rate:</label>
                        <input type="text" name="new_rate" id="new_rate">
                    </div>
                    <button type="submit" name="update_rate">Update Rate</button>
                </form>

                <?php
                
                ?>
                
            </div>
        </div>
    </main>
</div>

<?php get_footer(); ?>
