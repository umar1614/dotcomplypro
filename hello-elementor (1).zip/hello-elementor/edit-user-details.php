<?php
/*
Template Name: Edit User Details
*/

get_header();

// Check if the user ID is provided
if (isset($_GET['id'])) {
    $user_id = intval($_GET['id']);

    // Retrieve the user details from the database
    global $wpdb;
    $users_table = 'users';
    $user = $wpdb->get_row($wpdb->prepare("SELECT id, email, first_name, last_name, password FROM $users_table WHERE id = %d", $user_id));

    if ($user) {
        $first_name = $user->first_name;
        $last_name = $user->last_name;
        $email = $user->email;
        $password = $user->password;

        // Handle form submission for updating user details
        if (isset($_POST['update_user'])) {
            // Retrieve and sanitize the updated values
            $updated_first_name = sanitize_text_field($_POST['first_name']);
            $updated_last_name = sanitize_text_field($_POST['last_name']);
            $updated_email = sanitize_email($_POST['email']);
            $updated_password = sanitize_text_field($_POST['password']);

            // Update the user details in the database
            $wpdb->update(
                $users_table,
                array(
                    'first_name' => $updated_first_name,
                    'last_name' => $updated_last_name,
                    'email' => $updated_email,
                    'password' => $updated_password
                ),
                array('id' => $user_id),
                array('%s', '%s', '%s', '%s'),
                array('%d')
            );

            // Display user updated message
            echo '<h2 class="user-updated">User Updated</h2>';
        } else {
            // Display the form for editing user details
            ?>

            <div id="primary" class="content-area edit-user-details">
                <main id="main" class="site-main">
                    <div class="container">
                        <h2>Edit User Details</h2>
                        <form method="POST">
                            <div class="form-group">
                                <label for="first_name">First Name:</label>
                                <input type="text" name="first_name" id="first_name" value="<?php echo $first_name; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="last_name">Last Name:</label>
                                <input type="text" name="last_name" id="last_name" value="<?php echo $last_name; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="email">Email:</label>
                                <input type="email" name="email" id="email" value="<?php echo $email; ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Password:</label>
                                <input type="password" name="password" id="password" value="<?php echo $password; ?>" required>
                            </div>
                            <input type="submit" name="update_user" value="Update">
                        </form>
                    </div>
                </main>
            </div>

            <?php
        }
    } else {
        echo 'User not found.';
    }
} else {
    echo 'Invalid user ID.';
}

get_footer();
?>
