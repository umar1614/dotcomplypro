<?php
/* Template Name: Send Custom Message */

get_header();

global $wpdb;

$serverKey = 'AAAAvmTVNek:APA91bHPzrxwjvg_BsSTRUKVdC3tDrhAVf9Tk6D-nTNVg_utGDb-XhzfqN0M_34DIZjYiL41AymvR7BVJG2t4Ss-qUhxdb7OOJUSd0AwGipBlM9bqXqzTqcnF18IKh7_niuGWOTi1KVM';



// Process the form submission
if ( isset( $_POST['send_message'] ) && isset( $_POST['message'] ) ) {

    // Get the message content from the form
    $message_content = wp_kses_post( $_POST['message'] );

    $query = "SELECT * FROM `users`";

    $result = $wpdb -> get_results($query, ARRAY_A);

    if($result){
        foreach($result as $row){
            
            $data = array(
                "to" => $row['token'],
                "notification" => array(
                    "body" => $message_content,
                    "title" => 'Dot Comply Pro',
                )
            );

            // Convert the request body to JSON
            $json = json_encode($data);

            if ($json === false) {
                echo 'Error encoding JSON data: ' . json_last_error_msg();
            } else {
                // Set the POST request headers
                $headers = [
                    'Content-Type: application/json',
                    'Authorization: key=' . $serverKey
                ];

                // Send the POST request to Firebase API
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
                $response = curl_exec($ch);
                curl_close($ch);



                // Process the response
                if ($response === false) {
                    // Error occurred
                    echo 'Error sending push notification: ' . curl_error($ch);
                } 
            }
    
        }
    }

    // Insert message into the database
    $message_table = 'message';
    $wpdb->insert(
        $message_table,
        array(
            'message' => $message_content,
            'date' => current_time('mysql')
        )
    );

    
    $success_message = 'Message sent successfully to all users.';
}
?>

<div id="primary" class="content-area" style="width: 60%; margin:auto;">
    <main id="main" class="site-main">
        <div class="container message-form">
            </br>
            <h1>Send Custom Message To All Users</h1>
            </br>
            <form method="post" action="">
                <label for="message">Message:</label>
                <textarea name="message" id="message" rows="5" required></textarea>

                <input type="submit" class="button" style="
                margin-top: 20px; 
                background-color: #007bff; 
                color: #fff; 
                border: none; 
                padding: 10px 20px; 
                cursor: pointer; 
                transition: background-color 0.3s;" 
                
                onmouseover="this.style.backgroundColor='#0062cc'"
                onmouseout="this.style.backgroundColor='#007bff'" 
                name="send_message" value="Send Message">
            </form>

            <?php if ($success_message): ?>
            <div style="background-color: #007bff; color: #fff; text-align: center; padding: 10px; margin-top: 20px;">
                <?php echo $success_message; ?>
            </div>
            <?php endif; ?>
            
        </div>
    </main>
</div>

<?php get_footer(); ?>
