<?php
/* Template Name: Admin Registration */

get_header();

wp_enqueue_style('admin-registration-style', get_template_directory_uri() . '/admin-registration-style.css');


// Process the form submission
if ( isset( $_POST['submit_user'] ) ) {
    // Get the user data from the form
    $first_name = sanitize_text_field( $_POST['first_name'] );
    $last_name  = sanitize_text_field( $_POST['last_name'] );
    $username   = sanitize_text_field( $_POST['username'] );
    $email      = sanitize_email( $_POST['email'] );
    $password   = $_POST['password'];

    // Create the new user
    $user_id = wp_create_user( $username, $password, $email );

    if ( is_wp_error( $user_id ) ) {
        $error_message = $user_id->get_error_message();
        echo 'Error: ' . $error_message;
    } else {
        // Add first name and last name as user meta
        update_user_meta( $user_id, 'first_name', $first_name );
        update_user_meta( $user_id, 'last_name', $last_name );

        echo 'User created successfully. Username: ' . $username;
    }
}
?>

<div id="primary" class="content-area" style="width: 40%; margin:auto;">
    <main id="main" class="site-main">
        <div class="container user-reg">
            </br>
            <h1>Admin Registration</h1>
            </br>
            <form method="post" action="">
                <label for="first_name">First Name:</label>
                <input type="text" name="first_name" id="first_name" required>
                
                <label for="last_name">Last Name:</label>
                <input type="text" name="last_name" id="last_name" required>
            
                <label for="username">Username:</label>
                <input type="text" name="username" id="username" required>
                
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" required>
            
                <label for="password">Password:</label>
                <input type="password" name="password" id="password" required>
            
                <input type="submit" class="button" style="
                margin-top: 20px; 
                background-color: #007bff; 
                color: #fff; 
                border: none; 
                padding: 10px 20px; 
                cursor: pointer; 
                transition: background-color 0.3s;" 
                
                onmouseover="this.style.backgroundColor='#0062cc'"
                onmouseout="this.style.backgroundColor='#007bff'" 
                name="submit_user" value="Register">
            </form>
        </div>
    </main>
</div>

