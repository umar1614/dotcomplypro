<?php
/*
Template Name: Search User Details
*/

get_header();

wp_enqueue_style('search-user-details-style', get_template_directory_uri() . '/search-user-details-style.css');

// Check if the delete action is triggered
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $user_id = $_GET['id'];

    // Perform the user deletion
    global $wpdb;
    $table_name = 'users';
    $result = $wpdb->delete($table_name, ['ID' => $user_id]);

    if ($result !== false) {
        echo '<h2 style="margin: auto; width:30%; padding: 10px 20px; background-color: #33d1b8;">User deleted successfully.</h2>';
        echo '<script>window.location.href = "' . get_permalink() . '";</script>';
        exit();
    } else {
        echo '<p>Failed to delete user.</p>';
    }
}

?>
<br>
<div id="primary" class="content-area search-driver">
    <main id="main" class="site-main">
        <div class="container">
            <table id="driversTable" class="display">
                <thead>
                <tr>
                    <th>User Id</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>Details</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
                </thead>
                <tbody>
                <?php
                global $wpdb;
                $users_table = 'users';
                $users = $wpdb->get_results("SELECT id, email, first_name, last_name, password FROM $users_table");

                foreach ($users as $user) {
                    echo '<tr>';
                    echo '<td>' . $user->id . '</td>';
                    echo '<td>' . $user->first_name . '</td>';
                    echo '<td>' . $user->last_name . '</td>';
                    echo '<td>' . $user->email . '</td>';
                    echo '<td>' . $user->password . '</td>';
                    echo '<td>';
                    echo '<form method="GET" action="' . get_permalink(get_page_by_title('Details')) . '">';
                    echo '<input type="hidden" name="id" value="' . $user->id . '">';
                    echo '<button type="submit" class="button">View Details</button>';
                    echo '</form>';
                    echo '</td>';
                    echo '<td>';
                    echo '<form method="GET" action="' . get_permalink(get_page_by_title('Edit')) . '">';
                    echo '<input type="hidden" name="id" value="' . $user->id . '">';
                    echo '<button type="submit" class="button">Edit</button>';
                    echo '</form>';
                    echo '</td>';
                    echo '<td>';
                    echo '<a href="' . get_permalink() . '?action=delete&id=' . $user->id . '">Delete</a>';
                    echo '</td>';
                    echo '</tr>';
                }
                ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<?php get_footer(); ?>

<script>
    jQuery(document).ready(function($) {
        $('#driversTable').DataTable();
    });
</script>
