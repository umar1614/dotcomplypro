<?php
/*
Template Name: Add Notifications
*/

get_header();

wp_enqueue_style('add-notifications', get_template_directory_uri() . '/add-notifications.css');

if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    // Check if the form is submitted
    if (isset($_POST['submit'])) {
        // Retrieve the form data
        $deadline_45 = $_POST['deadline_45'];
        $deadline_30 = $_POST['deadline_30'];
        $deadline_15 = $_POST['deadline_15'];
        $description = $_POST['description'];

        // Check if the user already has notification data
        global $wpdb;
        $notifications_table = 'notifications';
        $existing_notification = $wpdb->get_row($wpdb->prepare("SELECT * FROM $notifications_table WHERE user_id = %d", $user_id));

        if ($existing_notification) {
            // Update the existing notification data
            $wpdb->update(
                $notifications_table,
                array(
                    'deadline_45' => $deadline_45,
                    'deadline_30' => $deadline_30,
                    'deadline_15' => $deadline_15,
                    'description' => $description
                ),
                array('user_id' => $user_id),
                array('%s', '%s', '%s', '%s'),
                array('%d')
            );

            // Display a success message for updating the notification
            echo '<div class="notification-success"><p>Notification has been updated successfully!</p></div>';
        } else {
            // Insert the new notification data into the database
            $wpdb->insert(
                $notifications_table,
                array(
                    'user_id' => $user_id,
                    'deadline_45' => $deadline_45,
                    'deadline_30' => $deadline_30,
                    'deadline_15' => $deadline_15,
                    'description' => $description
                ),
                array(
                    '%d',
                    '%s',
                    '%s',
                    '%s',
                    '%s'
                )
            );

            // Display a success message for adding the notification
            echo '<div class="notification-success"><p>Notification has been added successfully!</p></div>';
        }
    }
}
?>

<!-- Rest of the template code -->


<div id="primary" class="content-area">
    <main id="main" class="site-main">
        <div class="container add-notifications">
            <h1>Add Notifications</h1>
            </br>
            </br>
            <form method="POST" action="">
                <label for="deadline_45">45 Days Deadline Date and Time:</label>
                <input type="date" id="deadline_45" name="deadline_45" required>

                <label for="deadline_30">30 Days Deadline Date and Time:</label>
                <input type="date" id="deadline_30" name="deadline_30" required>

                <label for="deadline_15">15 Days Deadline Date and Time:</label>
                <input type="date" id="deadline_15" name="deadline_15" required>

                <label for="description">Description:</label>
                <textarea id="description" name="description" required></textarea>

                <input type="submit" name="submit" value="Save Notifications">
            </form>
        </div>
    </main>
</div>

<?php get_footer(); ?>
