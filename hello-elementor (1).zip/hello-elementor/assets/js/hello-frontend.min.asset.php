<?php return array('dependencies' => array(), 'version' => 'ee5d19831195aadc819c');
