<?php return array('dependencies' => array(), 'version' => '62f3d68782d60ead28e6');
