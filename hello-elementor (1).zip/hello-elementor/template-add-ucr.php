<?php
/*
Template Name: Add UCR
*/

get_header();

wp_enqueue_style('add-ucr-style', get_template_directory_uri() . '/add-ucr-style.css');

global $wpdb;

$serverKey = 'AAAAvmTVNek:APA91bHPzrxwjvg_BsSTRUKVdC3tDrhAVf9Tk6D-nTNVg_utGDb-XhzfqN0M_34DIZjYiL41AymvR7BVJG2t4Ss-qUhxdb7OOJUSd0AwGipBlM9bqXqzTqcnF18IKh7_niuGWOTi1KVM';

// Handle file uploads
if (isset($_FILES['ucr_file'])) {
    $user_id = $_POST['user_id'];

    // Define the upload directory path
    $upload_dir = 'MobileScripts/uploads/driver/' . $user_id . '/UCR/';
    $new_upload_dir = str_replace('MobileScripts/', '', $upload_dir);

    // Create the directory if it doesn't exist
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }

    // Get the uploaded file's information
    $file_name = $_FILES['ucr_file']['name'];
    $file_tmp = $_FILES['ucr_file']['tmp_name'];

    // Delete the existing file if it exists
    $ucr_table = 'ucr_file';
    $existing_file = $wpdb->get_row($wpdb->prepare("SELECT location, document_name FROM $ucr_table WHERE user_id = %d", $user_id));
    if ($existing_file) {
        $existing_file_path = ABSPATH . 'MobileScripts/' . $existing_file->location . $existing_file->document_name;
        if (file_exists($existing_file_path)) {
            unlink($existing_file_path);
        }
    }

    // Move the uploaded file to the destination folder
    move_uploaded_file($file_tmp, $upload_dir . $file_name);

    // Save file details in the database
    $data = array(
        'user_id' => $user_id,
        'location' => $new_upload_dir,
        'document_name' => $file_name
    );

    if ($existing_file) {
        $wpdb->update($ucr_table, $data, array('user_id' => $user_id));
    } else {
        $wpdb->insert($ucr_table, $data);
    }

    
}

if (isset($_POST['notify_user']) && isset($_POST['user_id'])) {
    $user_id = $_POST['user_id'];
    $message_content = 'Your UCR Form is ready!';

    $query = $wpdb->prepare("SELECT token FROM users WHERE id = %d", $user_id);

    $token = $wpdb->get_var($query);

    if ($token) {
        
        $data = array(
            "to" => $token,
            "notification" => array(
                "body" => $message_content,
                "title" => 'Dot Comply Pro',
            )
        );

        $json = json_encode($data);

        if ($json === false) {
            echo 'Error encoding JSON data: ' . json_last_error_msg();
        } else {
            // Set the POST request headers
            $headers = [
                'Content-Type: application/json',
                'Authorization: key=' . $serverKey
            ];

            // Send the POST request to Firebase API
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
            $response = curl_exec($ch);
            curl_close($ch);

            // Process the response
            if ($response === false) {
                // Error occurred
                echo 'Error sending push notification: ' . curl_error($ch);
            } 
        }
    } 


    // Save user ID and message to 'notify' table
    $notify_table = 'notify';
    $wpdb->insert($notify_table, array('user_id' => $user_id, 'message' => $message));
    
    // Show a popup notification
?>

<script>
    alert("Notification sent to user.");
</script>

<?php
}

?>
<br>
<div id="primary" class="content-area search-driver">
    <main id="main" class="site-main">
        <div class="container">
            <table id="driversTable" class="display">
                <thead>
                    <tr>
                        <th>User Id</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Upload UCR</th>
                        <th>UCR Document</th>
                        <th>Notify</th> 
                    </tr>
                </thead>
                <tbody>
                    <?php
                    global $wpdb;
                    $users_table = 'users';
                    $ucr_table = 'ucr_file';
                    $users = $wpdb->get_results("SELECT id, email, first_name, last_name, password FROM $users_table");

                    foreach ($users as $user) {
                        echo '<tr>';
                        echo '<td>' . $user->id . '</td>';
                        echo '<td>' . $user->first_name . '</td>';
                        echo '<td>' . $user->last_name . '</td>';
                        echo '<td>' . $user->email . '</td>';
                        echo '<td>';
                        echo '<form method="POST" enctype="multipart/form-data" action="' . get_permalink(get_page_by_title('Your Drivers Template')) . '" style="display: flex">';
                        echo '<input type="hidden" name="user_id" value="' . $user->id. '" style="display: inline-block;">'; // Pass the user ID
                        echo '<input type="file" name="ucr_file" accept=".pdf,.doc,.docx" style="display: inline-block;">';
                        echo '<button type="submit" class="upload-button" style="display: inline-block;">Upload File</button>';
                        echo '</form>';
                        echo '</td>';
                        echo '<td>';

                        // Get the location and document name of the UCR file
                        $ucr_row = $wpdb->get_row($wpdb->prepare("SELECT location, document_name FROM $ucr_table WHERE user_id = %d", $user->id));

                        // Check if the row exists
                        if ($ucr_row) {
                            $ucr_path = $ucr_row->location . $ucr_row->document_name;
                            $ucr_file = ABSPATH . 'MobileScripts/' . $ucr_path;

                            // Check if the file exists
                            if (file_exists($ucr_file)) {
                                echo '<a href="' . site_url('/') . 'MobileScripts/' . $ucr_path . '" target="_blank">View UCR</a>';
                            } else {
                                echo 'UCR file not found';
                            }
                        } else {
                            echo 'No UCR file';
                        }

                        echo '</td>';

                        // Notify button
                        echo '<td>';
                        echo '<form method="POST" action="">';
                        echo '<input type="hidden" name="user_id" value="' . $user->id . '">';
                        echo '<button type="submit" class="upload-button" name="notify_user">Notify User</button>';
                        echo '</form>';
                        echo '</td>';

                        echo '</tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<?php get_footer(); ?>

<script>
    jQuery(document).ready(function ($) {
        $('#driversTable').DataTable();
    });

    // Validate file upload
    jQuery('form').submit(function (e) {
        var fileInput = jQuery(this).find('input[type="file"]');
        if (fileInput.val() === '') {
            e.preventDefault();
            alert('Please choose a file to upload.');
        }
    });
</script>
