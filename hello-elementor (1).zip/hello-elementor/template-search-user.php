<?php
/*
Template Name: Search User
*/

get_header();

wp_enqueue_style('search-user', get_template_directory_uri() . '/style-search-user.css');
?>
<br><br>
<div id="primary" class="content-area">
    <main id="main" class="site-main">
        <div class="container">
            <table id="user-table" class="display">
                <thead>
                    <tr>
                        <th>User Id</th>
                        <th>Email</th>
                        <th>Deadline 45</th>
                        <th>Deadline 30</th>
                        <th>Deadline 15</th>
                        <th>Description</th>
                        <th>Add Notifications</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    global $wpdb;
                    $users_table = 'users';
                    $notifications_table = 'notifications';
                    $users = $wpdb->get_results("SELECT u.id, u.email, n.deadline_45, n.deadline_30, n.deadline_15, n.description
                                                FROM $users_table AS u
                                                LEFT JOIN $notifications_table AS n ON u.id = n.user_id");

                    foreach ($users as $user) {
                        echo '<tr>';
                        echo '<td>' . $user->id . '</td>';
                        echo '<td>' . $user->email . '</td>';
                        echo '<td>' . $user->deadline_45 . '</td>';
                        echo '<td>' . $user->deadline_30 . '</td>';
                        echo '<td>' . $user->deadline_15 . '</td>';
                        echo '<td>' . $user->description . '</td>';
                        echo '<td>';
                        echo '<form method="GET" action="' . get_permalink(get_page_by_title('Add Notifications')) . '">';
                        echo '<input type="hidden" name="id" value="' . $user->id . '">';
                        echo '<button type="submit" class="button">Add Notifications</button>';
                        echo '</form>';
                        echo '</td>';
                        echo '</tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<?php get_footer(); ?>

<script>
jQuery(document).ready(function($) {
    $('#user-table').DataTable({
        searching: true, // Enable searching
        paging: true,     // Enable pagination
    });

    $('.add-notification-btn').click(function() {
        var userId = $(this).data('user-id');
        window.location.href = '<?php echo home_url('/add-notifications'); ?>?user_id=' + userId;
    });
});
</script>


