<?php
/*
Template Name: User Registration
*/



get_header(); ?>

<div id="primary" class="content-area add-user">
    <main id="main" class="site-main">
        <div class="container">
            <h1>User Registration</h1>
            </br>
            </br>
            <form method="post" class="reg-form">
                <div class="form-group">
                    <label for="first_name">First Name:</label>
                    <input type="text" name="first_name" id="first_name" required>
                </div>
                <div class="form-group">
                    <label for="last_name">Last Name:</label>
                    <input type="text" name="last_name" id="last_name" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" name="email" id="email" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="text" name="password" id="password" required>
                </div>
                <div class="form-group">
                    <input type="submit" name="submit" value="Submit">
                </div>
            </form>
        </div>
    </main>
</div>

<?php
// Add the form submission handling logic here
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
    $first_name = sanitize_text_field($_POST['first_name']);
    $last_name = sanitize_text_field($_POST['last_name']);
    $email = sanitize_email($_POST['email']);
    $password = sanitize_text_field($_POST['password']);

    // Validate the form data (you can add additional validation if needed)

    // Insert data into the database
    global $wpdb;
    $table_name ='users';

    $wpdb->insert(
        $table_name,
        array(
            'first_name' => $first_name,
            'last_name' => $last_name,
            'email' => $email,
            'password' => $password,
        )
    );

    // Display success message
      if (isset($_POST['submit'])) {
    echo '<div class="updated"><h2>User added successfully!</h2></div>';
  }
}
?>

<?php get_footer(); ?>
